const FIELD_SIZE = 60;

let game_state = {};

function renderField() {
  for (let i = 0; i < FIELD_SIZE; i++){
    for (let j = 0; j < FIELD_SIZE; j++){
      const live = game_state[`${i}_${j}`];
      const div = $(`#${i}_${j}`)[0];
      if (live) {
        if (!div.classList.contains("selected"))
          div.classList.add("selected");
      } else {
        if (div.classList.contains("selected")) {
          div.classList.remove("selected");
        }
      }
    }
  }
}

function onSpacePressed() {
  $.post("game_calculator.php", game_state, function(data) {
    console.log(Object.keys(game_state).length);
    
    game_state = JSON.parse(data);
    console.log(Object.keys(game_state).length);
    
    renderField();
  })
}

function runGame() {
  $(document).on('keypress', function(e) {
    if (e.originalEvent.code == "Space"){
      onSpacePressed();
    }
  });
  const root = $("#root");
  for (let i = 0; i < FIELD_SIZE; i++) {
    const newLine = document.createElement("div");
    newLine.className = `game__line`;
    root.append(newLine);
    for(let j = 0; j < FIELD_SIZE; j++) {
      const newDiv = document.createElement("div");
      newDiv.className = 'game__cell';
      newDiv.id = `${i}_${j}`;
      game_state[`${i}_${j}`] = 0;
      newDiv.onclick = () => {
        if (game_state[`${i}_${j}`]) {
          game_state[`${i}_${j}`] = 0;
        } else {
          game_state[`${i}_${j}`] = 1;
        }
        if (game_state[`${i}_${j}`]) {
          newDiv.classList.add("selected");
        } else {
          newDiv.classList.remove("selected");
        }
      };
      newLine.appendChild(newDiv);
    }
  }
}