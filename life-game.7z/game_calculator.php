<?php 
  $test = $_POST;
  $result = array();

  foreach ($test as $key => $value) {
    list($x, $y) = explode('_', $key);
    $countNeightbors = calculateNeighbors($test, $x, $y);

    if ($countNeightbors == 3 or $countNeightbors == 2 and isAlive($test, $x, $y)) {
      $result[$key] = 1;
    } elseif ($countNeightbors == 3 and !isAlive($test, $x, $y)) {
      $result[$key] = 1;
    } elseif ($countNeightbors > 3 or $countNeightbors < 2) {
      $result[$key] = 0;
    } else {
      $result[$key] = 0;
    }
  }

  echo json_encode($result);    

  function calculateNeighbors($arr, $x, $y) {
    $count = 0;
    if (isAlive($arr, $x-1, $y-1)) $count ++;
    if (isAlive($arr, $x, $y-1)) $count ++;
    if (isAlive($arr, $x+1, $y-1)) $count ++;
    if (isAlive($arr, $x-1, $y)) $count ++;
    if (isAlive($arr, $x+1, $y)) $count ++;
    if (isAlive($arr, $x-1, $y+1)) $count ++;
    if (isAlive($arr, $x, $y+1)) $count ++;
    if (isAlive($arr, $x+1, $y+1)) $count ++;
    return $count;
  }
  
  function isAlive($arr, $x, $y) {
    $pointKey = buildKey($x, $y);
    return array_key_exists($pointKey, $arr) and $arr[$pointKey] === "1";
  }

  function buildKey($x, $y) {
    $id = $x;
    $id .= "_";
    $id .= $y;
    return $id;
  }
?>